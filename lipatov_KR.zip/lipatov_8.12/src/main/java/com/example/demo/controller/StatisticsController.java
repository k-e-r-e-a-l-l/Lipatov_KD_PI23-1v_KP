package com.example.demo.controller;

import com.example.demo.model.InsuranceProduct;
import com.example.demo.model.User;
import com.example.demo.repository.InsuranceProductRepository;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class StatisticsController {

    @Autowired
    private InsuranceProductRepository productRepository;

    @Autowired
    private UserRepository userRepository;

    @GetMapping("/statistics")
    @PreAuthorize("hasAnyRole('USER','MANAGER','ADMIN','WORKER')")
    public String showStatistics(Model model) {
        // Статистика по страховкам
        List<InsuranceProduct> allProducts = productRepository.findAll();
        int totalProducts = allProducts.size();

        // Группировка по типам
        Map<String, Long> productsByType = new HashMap<>();
        for (InsuranceProduct product : allProducts) {
            String type = product.getType() != null ? product.getType() : "Без типа";
            productsByType.put(type, productsByType.getOrDefault(type, 0L) + 1);
        }

        // Статистика по пользователям
        List<User> allUsers = userRepository.findAll();
        long totalUsers = allUsers.size();

        // Получаем реальные данные для графиков
        Map<LocalDate, Long> insuranceGrowthData = getRealInsuranceGrowthData(allProducts);
        Map<LocalDate, Long> userGrowthData = getRealUserGrowthData(allUsers);

        // Преобразуем данные в списки для графиков
        List<String> dates = new ArrayList<>();
        List<Long> insuranceCounts = new ArrayList<>();
        List<Long> userCounts = new ArrayList<>();

        prepareChartData(insuranceGrowthData, userGrowthData, dates, insuranceCounts, userCounts);

        model.addAttribute("totalProducts", totalProducts);
        model.addAttribute("productsByType", productsByType);
        model.addAttribute("totalUsers", totalUsers);
        model.addAttribute("dates", dates);
        model.addAttribute("insuranceCounts", insuranceCounts);
        model.addAttribute("userCounts", userCounts);

        return "statistics";
    }

    private Map<LocalDate, Long> getRealInsuranceGrowthData(List<InsuranceProduct> products) {
        // Группируем продукты по дате создания (только дата, без времени)
        Map<LocalDate, Long> dailyCounts = products.stream()
                .filter(p -> p.getCreatedAt() != null)
                .collect(Collectors.groupingBy(
                        p -> p.getCreatedAt().toLocalDate(),
                        Collectors.counting()
                ));

        // Сортируем по дате
        TreeMap<LocalDate, Long> sortedMap = new TreeMap<>(dailyCounts);

        // Рассчитываем кумулятивную сумму
        TreeMap<LocalDate, Long> cumulativeMap = new TreeMap<>();
        long cumulative = 0;

        for (Map.Entry<LocalDate, Long> entry : sortedMap.entrySet()) {
            cumulative += entry.getValue();
            cumulativeMap.put(entry.getKey(), cumulative);
        }

        return cumulativeMap;
    }

    private Map<LocalDate, Long> getRealUserGrowthData(List<User> users) {
        // Группируем пользователей по дате создания
        Map<LocalDate, Long> dailyCounts = users.stream()
                .filter(u -> u.getCreatedAt() != null)
                .collect(Collectors.groupingBy(
                        u -> u.getCreatedAt().toLocalDate(),
                        Collectors.counting()
                ));

        // Сортируем по дате
        TreeMap<LocalDate, Long> sortedMap = new TreeMap<>(dailyCounts);

        // Рассчитываем кумулятивную сумму
        TreeMap<LocalDate, Long> cumulativeMap = new TreeMap<>();
        long cumulative = 0;

        for (Map.Entry<LocalDate, Long> entry : sortedMap.entrySet()) {
            cumulative += entry.getValue();
            cumulativeMap.put(entry.getKey(), cumulative);
        }

        return cumulativeMap;
    }

    private void prepareChartData(Map<LocalDate, Long> insuranceData,
                                  Map<LocalDate, Long> userData,
                                  List<String> dates,
                                  List<Long> insuranceCounts,
                                  List<Long> userCounts) {

        // Объединяем все даты из обоих наборов данных
        Set<LocalDate> allDates = new TreeSet<>();
        allDates.addAll(insuranceData.keySet());
        allDates.addAll(userData.keySet());

        // Если данных нет, создаем искусственные
        if (allDates.isEmpty()) {
            LocalDate today = LocalDate.now();
            for (int i = 30; i >= 0; i--) {
                LocalDate date = today.minusDays(i);
                allDates.add(date);
            }
        }

        // Преобразуем даты и заполняем значения
        long lastInsuranceCount = 0;
        long lastUserCount = 0;

        for (LocalDate date : allDates) {
            // Форматируем дату
            String formattedDate = date.getDayOfMonth() + "/" + date.getMonthValue();
            dates.add(formattedDate);

            // Получаем значения для текущей даты
            long insuranceCount = insuranceData.getOrDefault(date, lastInsuranceCount);
            long userCount = userData.getOrDefault(date, lastUserCount);

            insuranceCounts.add(insuranceCount);
            userCounts.add(userCount);

            // Сохраняем последние значения для дат без данных
            lastInsuranceCount = insuranceCount;
            lastUserCount = userCount;
        }
    }
}