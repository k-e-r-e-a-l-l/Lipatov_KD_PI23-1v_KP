package com.example.demo.controller;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import com.example.demo.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/admin")
@PreAuthorize("hasRole('ADMIN')")
public class AdminController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private UserService userService;

    @GetMapping("/users")
    public String users(Model model, Authentication authentication) {
        List<User> users = userRepository.findAll();
        List<Role> roles = roleRepository.findAll();
        model.addAttribute("users", users);
        model.addAttribute("roles", roles);

        // Добавляем имя текущего пользователя для проверки
        if (authentication != null) {
            model.addAttribute("currentUsername", authentication.getName());
        }

        return "admin/users";
    }

    @PostMapping("/changeRole")
    public String changeRole(@RequestParam Long userId,
                             @RequestParam String roleName,
                             Authentication authentication,
                             RedirectAttributes ra) {

        // Получаем текущего пользователя
        User currentUser = userService.findByUsername(authentication.getName());

        // Проверяем, не пытается ли пользователь изменить свою собственную роль
        if (currentUser != null && currentUser.getId().equals(userId)) {
            ra.addFlashAttribute("error", "Вы не можете изменить свою собственную роль!");
            return "redirect:/admin/users";
        }

        userService.changeUserRole(userId, roleName);
        return "redirect:/admin/users";
    }

    @PostMapping("/delete/{id}")
    public String deleteUser(@PathVariable Long id,
                             Authentication auth,
                             RedirectAttributes ra) {

        // Получаем текущего пользователя через сервис
        User current = userService.findByUsername(auth.getName());
        if (current != null && current.getId().equals(id)) {
            ra.addFlashAttribute("error", "Нельзя удалить свой собственный аккаунт!");
            return "redirect:/admin/users";
        }

        userService.deleteUser(id);
        return "redirect:/admin/users";
    }
}