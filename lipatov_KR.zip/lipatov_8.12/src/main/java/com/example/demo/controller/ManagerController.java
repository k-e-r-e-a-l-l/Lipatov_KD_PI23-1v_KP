package com.example.demo.controller;

import com.example.demo.model.InsuranceProduct;
import com.example.demo.service.InsuranceProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/manager")
@PreAuthorize("hasAnyRole('MANAGER','ADMIN')")
public class ManagerController {

    @Autowired
    private InsuranceProductService productService;

    @GetMapping("/create")
    public String createForm(Model model) {
        model.addAttribute("product", new InsuranceProduct());
        return "manager/edit";
    }

    @GetMapping("/edit/{id}")
    public String editForm(@PathVariable Long id, Model model) {
        InsuranceProduct p = productService.findById(id);
        if (p == null) {
            return "redirect:/dashboard";
        }
        model.addAttribute("product", p);
        return "manager/edit";
    }

    @PostMapping("/save")
    public String save(@ModelAttribute @Valid InsuranceProduct product,
                       BindingResult result,
                       RedirectAttributes redirectAttributes,
                       Model model) {

        // Проверяем уникальность кода (только для новых записей)
        if (product.getId() == null) {
            InsuranceProduct existing = productService.findByCode(product.getCode());
            if (existing != null) {
                result.rejectValue("code", "error.code", "Продукт с таким кодом уже существует");
            }
        }

        if (result.hasErrors()) {
            // Добавляем product обратно в модель для отображения формы с ошибками
            model.addAttribute("product", product);
            return "manager/edit";
        }

        try {
            productService.save(product);
            redirectAttributes.addFlashAttribute("successMessage",
                    "Страховка успешно " + (product.getId() != null ? "обновлена" : "добавлена"));
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage",
                    "Ошибка при сохранении страховки: " + e.getMessage());
            // При ошибке возвращаемся на форму создания
            model.addAttribute("product", product);
            return "manager/edit";
        }

        return "redirect:/dashboard";
    }

    @PostMapping("/delete/{id}")
    public String delete(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        try {
            productService.deleteById(id);
            redirectAttributes.addFlashAttribute("successMessage", "Страховка успешно удалена");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Ошибка при удалении страховки: " + e.getMessage());
        }
        return "redirect:/dashboard";
    }
}