package com.example.demo.service;

import com.example.demo.model.InsuranceProduct;
import com.example.demo.repository.InsuranceProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class InsuranceProductService {

    @Autowired
    private InsuranceProductRepository productRepository;

    public List<InsuranceProduct> findAll() {
        return productRepository.findAll();
    }

    public InsuranceProduct findById(Long id) {
        Optional<InsuranceProduct> product = productRepository.findById(id);
        return product.orElse(null);
    }

    // Добавляем метод поиска по коду
    public InsuranceProduct findByCode(String code) {
        if (code == null || code.trim().isEmpty()) {
            return null;
        }

        return productRepository.findAll().stream()
                .filter(product -> code.equalsIgnoreCase(product.getCode()))
                .findFirst()
                .orElse(null);
    }

    public InsuranceProduct save(InsuranceProduct product) {
        return productRepository.save(product);
    }

    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }

    // Метод для поиска продуктов по различным полям
    public List<InsuranceProduct> search(String searchTerm) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return productRepository.findAll();
        }

        String lowerCaseSearch = searchTerm.toLowerCase();

        return productRepository.findAll().stream()
                .filter(product ->
                        (product.getType() != null && product.getType().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getName() != null && product.getName().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getShortDescription() != null && product.getShortDescription().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getFullDescription() != null && product.getFullDescription().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getCoverage() != null && product.getCoverage().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getConditions() != null && product.getConditions().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getDocuments() != null && product.getDocuments().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getPriceInfo() != null && product.getPriceInfo().toLowerCase().contains(lowerCaseSearch)) ||
                                (product.getCode() != null && product.getCode().toLowerCase().contains(lowerCaseSearch)) // Добавляем поиск по коду
                )
                .collect(Collectors.toList());
    }

    // Метод для получения всех продуктов с сортировкой
    public List<InsuranceProduct> findAllSorted(String sort) {
        List<InsuranceProduct> products = productRepository.findAll();

        if ("type".equals(sort)) {
            products.sort(Comparator.comparing(InsuranceProduct::getType,
                    Comparator.nullsFirst(String::compareToIgnoreCase)));
        } else {
            // Сортировка по имени по умолчанию
            products.sort(Comparator.comparing(InsuranceProduct::getName,
                    Comparator.nullsFirst(String::compareToIgnoreCase)));
        }

        return products;
    }

    // Комбинированный метод для поиска и сортировки
    public List<InsuranceProduct> searchAndSort(String searchTerm, String sort) {
        List<InsuranceProduct> products;

        if (searchTerm != null && !searchTerm.trim().isEmpty()) {
            products = search(searchTerm);
        } else {
            products = productRepository.findAll();
        }

        // Применяем сортировку
        if ("type".equals(sort)) {
            products.sort(Comparator.comparing(InsuranceProduct::getType,
                    Comparator.nullsFirst(String::compareToIgnoreCase)));
        } else {
            products.sort(Comparator.comparing(InsuranceProduct::getName,
                    Comparator.nullsFirst(String::compareToIgnoreCase)));
        }

        return products;
    }
}