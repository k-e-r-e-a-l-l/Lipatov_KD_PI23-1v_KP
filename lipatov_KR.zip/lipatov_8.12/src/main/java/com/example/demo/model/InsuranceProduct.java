package com.example.demo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "insurance_products")
public class InsuranceProduct {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Код продукта обязателен")
    @Size(max = 50, message = "Код продукта не должен превышать 50 символов")
    @Column(unique = true)
    private String code;

    @NotBlank(message = "Тип страховки обязателен")
    @Size(max = 100, message = "Тип страховки не должен превышать 100 символов")
    private String type;

    @NotBlank(message = "Название обязательно")
    @Size(max = 200, message = "Название не должно превышать 200 символов")
    private String name;

    @NotBlank(message = "Краткое описание обязательно")
    @Size(max = 500, message = "Краткое описание не должно превышать 500 символов")
    private String shortDescription;

    @Size(max = 2000, message = "Полное описание не должно превышать 2000 символов")
    private String fullDescription;

    @Size(max = 500, message = "Покрытие не должно превышать 500 символов")
    private String coverage;

    @Size(max = 1000, message = "Условия не должны превышать 1000 символов")
    private String conditions;

    @Size(max = 500, message = "Документы не должны превышать 500 символов")
    private String documents;

    @Size(max = 200, message = "Информация о стоимости не должна превышать 200 символов")
    private String priceInfo;

    @CreationTimestamp
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    // Конструкторы, геттеры и сеттеры
    public InsuranceProduct() {}

    public InsuranceProduct(String code, String type, String name, String shortDescription) {
        this.code = code;
        this.type = type;
        this.name = name;
        this.shortDescription = shortDescription;
    }

    // Геттеры и сеттеры
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getShortDescription() { return shortDescription; }
    public void setShortDescription(String shortDescription) { this.shortDescription = shortDescription; }

    public String getFullDescription() { return fullDescription; }
    public void setFullDescription(String fullDescription) { this.fullDescription = fullDescription; }

    public String getCoverage() { return coverage; }
    public void setCoverage(String coverage) { this.coverage = coverage; }

    public String getConditions() { return conditions; }
    public void setConditions(String conditions) { this.conditions = conditions; }

    public String getDocuments() { return documents; }
    public void setDocuments(String documents) { this.documents = documents; }

    public String getPriceInfo() { return priceInfo; }
    public void setPriceInfo(String priceInfo) { this.priceInfo = priceInfo; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

}