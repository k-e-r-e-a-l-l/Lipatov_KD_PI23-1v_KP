package com.example.demo.controller;

import com.example.demo.service.InsuranceProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DashboardController {

    @Autowired
    private InsuranceProductService insuranceProductService;

    @GetMapping("/dashboard")
    public String dashboard(
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "sortOrder") String sort,
            Model model,
            Authentication auth) {

        var products = (search != null && !search.isBlank()) ? insuranceProductService.search(search) : insuranceProductService.findAllSorted(sort);

        model.addAttribute("products", products);
        model.addAttribute("search", search);
        model.addAttribute("sort", sort);

        if (auth != null) {
            model.addAttribute("username", auth.getName());

            boolean isUser = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_USER"));
            boolean isWorker = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_WORKER"));
            boolean isManager = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_MANAGER"));
            boolean isAdmin = auth.getAuthorities().stream().anyMatch(a -> a.getAuthority().equals("ROLE_ADMIN"));

            model.addAttribute("isUser", isUser);
            model.addAttribute("isWorker", isWorker);
            model.addAttribute("isManager", isManager);
            model.addAttribute("isAdmin", isAdmin);
        }

        return "dashboard";
    }
}
