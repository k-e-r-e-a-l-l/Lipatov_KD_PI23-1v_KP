package com.example.demo.controller;

import com.example.demo.service.UserService;
import jakarta.validation.constraints.NotBlank;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    @GetMapping("/login")
    public String loginForm(@RequestParam(value = "error", required = false) String error,
                            @RequestParam(value = "registered", required = false) String registered,
                            Model model) {
        if (error != null) {
            model.addAttribute("errorMessage", "Неверное имя пользователя или пароль");
        }
        if (registered != null) {
            model.addAttribute("successMessage", "Регистрация успешна! Теперь вы можете войти.");
        }
        return "login";
    }

    @GetMapping("/register")
    public String registerForm(Model model) {
        // Инициализируем пустую модель для нового пользователя
        model.addAttribute("username", "");
        return "register";
    }

    @PostMapping("/register")
    public String register(@RequestParam @NotBlank String username,
                           @RequestParam @NotBlank String password,
                           Model model,
                           RedirectAttributes redirectAttributes) {
        try {
            userService.registerUser(username, password, "ROLE_USER");
            // Успешная регистрация - редирект на логин с сообщением
            redirectAttributes.addFlashAttribute("successMessage",
                    "Регистрация успешна! Теперь вы можете войти.");
            return "redirect:/login";
        } catch (IllegalArgumentException ex) {
            // Если пользователь уже существует - показываем ошибку на той же странице
            model.addAttribute("errorMessage",
                    "Пользователь с именем '" + username + "' уже существует. Пожалуйста, выберите другое имя.");
            model.addAttribute("username", username); // Сохраняем введенное имя для повторного отображения
            return "register";
        }
    }

    @GetMapping({"/"})
    public String index() {
        return "redirect:/login";
    }
}