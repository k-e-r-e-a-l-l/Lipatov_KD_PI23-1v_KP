package com.example.demo.config;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

import java.util.Collection;

@ControllerAdvice(annotations = Controller.class)
public class GlobalUserModelAdvice {

    @ModelAttribute("username")
    public String username(Authentication authentication) {
        if (authentication == null) return null;
        return authentication.getName();
    }

    @ModelAttribute("isAdmin")
    public Boolean isAdmin(Authentication authentication) {
        if (authentication == null) return false;
        Collection<? extends GrantedAuthority> auths = authentication.getAuthorities();
        return auths.stream().anyMatch(a ->
                a.getAuthority().equals("ROLE_ADMIN") || a.getAuthority().equals("ADMIN"));
    }

    @ModelAttribute("isManager")
    public Boolean isManager(Authentication authentication) {
        if (authentication == null) return false;
        Collection<? extends GrantedAuthority> auths = authentication.getAuthorities();
        return auths.stream().anyMatch(a ->
                a.getAuthority().equals("ROLE_MANAGER") || a.getAuthority().equals("MANAGER"));
    }
}