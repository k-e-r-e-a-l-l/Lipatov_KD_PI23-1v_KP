package com.example.demo.repository;

import com.example.demo.model.InsuranceProduct;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;

public interface InsuranceProductRepository extends JpaRepository<InsuranceProduct, Long> {

    InsuranceProduct findByCode(String code);

    @Query("SELECT p FROM InsuranceProduct p WHERE " +
            "LOWER(p.name) LIKE LOWER(concat('%', :keyword, '%')) " +
            "OR LOWER(p.code) LIKE LOWER(concat('%', :keyword, '%')) " +
            "OR LOWER(p.shortDescription) LIKE LOWER(concat('%', :keyword, '%')) " +
            "OR LOWER(p.fullDescription) LIKE LOWER(concat('%', :keyword, '%')) " +
            "OR LOWER(p.type) LIKE LOWER(concat('%', :keyword, '%'))")
    List<InsuranceProduct> searchFull(String keyword);
}
