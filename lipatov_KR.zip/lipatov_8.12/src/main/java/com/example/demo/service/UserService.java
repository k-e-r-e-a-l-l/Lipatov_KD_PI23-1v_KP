package com.example.demo.service;

import com.example.demo.model.Role;
import com.example.demo.model.User;
import com.example.demo.repository.RoleRepository;
import com.example.demo.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public User findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    @Transactional
    public void registerUserIfNotExists(String username, String password, String roleName) {
        if (username == null || username.isBlank()) throw new IllegalArgumentException("username empty");
        if (password == null || password.isBlank()) throw new IllegalArgumentException("password empty");

        if (findByUsername(username) != null) {
            return; // уже есть
        }

        Role role = roleRepository.findByName(roleName);
        if (role == null) {
            role = new Role();
            role.setName(roleName);
            role = roleRepository.save(role);
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(passwordEncoder.encode(password));

        Set<Role> roles = new HashSet<>();
        roles.add(role);
        user.setRoles(roles);

        userRepository.save(user);
    }

    @Transactional
    public void registerUser(String username, String password, String roleName) {
        if (findByUsername(username) != null) {
            throw new IllegalArgumentException("User already exists: " + username);
        }
        registerUserIfNotExists(username, password, roleName);
    }

    @Transactional
    public void changeUserRole(Long userId, String roleName) {
        Optional<User> maybe = userRepository.findById(userId);
        if (maybe.isEmpty()) return;
        User user = maybe.get();

        Role role = roleRepository.findByName(roleName);
        if (role == null) {
            role = new Role();
            role.setName(roleName);
            role = roleRepository.save(role);
        }

        Set<Role> roles = new HashSet<>();
        roles.add(role);
        user.setRoles(roles);

        userRepository.save(user);
    }

    @Transactional
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }
}
