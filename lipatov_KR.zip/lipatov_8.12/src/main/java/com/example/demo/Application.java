package com.example.demo;

import com.example.demo.model.InsuranceProduct;
import com.example.demo.service.InsuranceProductService;
import com.example.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Application implements CommandLineRunner {

	@Autowired
	private UserService userService;

	@Autowired
	private InsuranceProductService insuranceProductService;

	public static void main(String[] args) {
		SpringApplication.run(Application.class, args);
	}

	@Override
	public void run(String... args) throws Exception {

		// Создаём роли и пользователей (если ещё нет)
		userService.registerUserIfNotExists("admin", "123", "ROLE_ADMIN");
		userService.registerUserIfNotExists("manager", "123", "ROLE_MANAGER");
		userService.registerUserIfNotExists("worker", "123", "ROLE_WORKER");
		userService.registerUserIfNotExists("user1", "123", "ROLE_USER");


	}

	private void createIfNotExists(
			String code,
			String name,
			String type,
			String shortDesc,
			String fullDesc,
			String coverage,
			String conditions,
			String docs,
			String price,
			int order
	) {
		if (insuranceProductService.findByCode(code) == null) {

			InsuranceProduct p = new InsuranceProduct();
			p.setCode(code);
			p.setName(name);
			p.setType(type);
			p.setShortDescription(shortDesc);
			p.setFullDescription(fullDesc);
			p.setCoverage(coverage);
			p.setConditions(conditions);
			p.setDocuments(docs);
			p.setPriceInfo(price);


			insuranceProductService.save(p);
		}
	}
}
